//
//  detailNVC.swift
//  swift_Wheather
//
//  Created by user on 23.09.2021.
//

import UIKit
import Alamofire
import SwiftyJSON

class detailNVC: UINavigationController {
   

}
